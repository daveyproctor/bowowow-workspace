<!DOCTYPE html>
<html>
    <?php
        // TODO
    ?>
    <head>
        <title>Submitted!</title>
        <link rel="stylesheet" href="styles.css" type="text/css"/>
    </head>
    <body>
        <h2>Your response has been submitted!</h2>
        <form action="/">
            <input type="submit" value="Submit another response!"/>
        </form> 
    </body>
<html></html>