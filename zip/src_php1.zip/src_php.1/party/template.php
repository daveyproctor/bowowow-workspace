<?php
    // useful globals
    $font_size = 12;
    $font_name = "Times";

    require_once("helpers.php");

    // create the PDF
    $pdf = create_pdf();

    // print a fun image at the top left corner, two inches wide
    insert_image($pdf, "muppet.jpg", 2.0);
    
    // print the address line
    print_address($pdf, "First Last", "Address", "City, State ZIP");
  
    // print today's date (after formatting it as a string with date())
    print_date($pdf, date("F j, Y"));
    
    // write the message body
    print_greeting($pdf, "First");
    
    // print the body of the message
    print_body($pdf, "body.txt");
  
    // write the signature area
    print_signature($pdf, "Sincerely,", "Sender");
    
    // save the file
    save_as($pdf, "output/template.pdf");

?>