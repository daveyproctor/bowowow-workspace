<?php
    /* include the fpdf library, which allows us to generate PDFs
       programmatically via PHP */
    require_once('vendor/fpdf.php');

    /* create_pdf()
       parameters: none
       output: a PDF file object
       
       Creates a PDF file with default letter-sized pages and units of
       measurement specified as inches, sets the margins for the page, and
       establishes which font will be used
    */
    function create_pdf()
    {
        // allow function to utilize variables declared in invite.php
        global $font_size, $font_name;
        
        // use fpdf constructor to create a pdf object
        $pdf = new FPDF('P','in','letter');
        
        // sets the margins of each pdf page and adds 1 page to pdf object
        $pdf->SetMargins(1.0, 1.0);
        $pdf->AddPage();
        
        // sets the font preferences as obtained from invite.php
        $pdf->SetFont($font_name, null, $font_size);
        
        // all done!
        return $pdf;
    }
    
    /* insert_image()
       parameters (3): pdf object, filename of image, preferred width (inches)
       output: none (writes directly to $pdf)
       
       Writes the address portion of the letter, pursuant to the entered
       parameters, saving to the specified pdf object
    */    
    function insert_image($pdf, $image, $width)
    {
        // put the image into the pdf file, left-aligned, preserving aspect
        // ratio of the original, scaled to the width
        $pdf->Image($image, null, null, $width);
        
        // for cleanliness, leave quarter-inch of space before next print
        skip($pdf, 0.25);
    }
    
    /* print_address()
       parameters (4): pdf object, name string, address string, city/state/zip 
                       string
       output: none (writes directly to $pdf)
       
       Writes the address portion of the letter, pursuant to the entered
       parameters, saving to the specified pdf object
    */
    function print_address($pdf, $name, $address, $citystatezip)
    {
        // writes each of the three lines of the address block, left-justified
        print_line($pdf, $name, "L");
        print_line($pdf, $address, "L");
        print_line($pdf, $citystatezip, "L");
        
        // for cleanliness, leave half-inch of space before next print
        skip($pdf, 0.5);
    }
    
    /* print_body()
       parameters (2): pdf object, relative path to file
       output: none (writes directly to $pdf)
       
       Attempts to open a file and write its contents, verbatim, to the
       pdf object
    */
    function print_body($pdf, $file)
    {
        // allow function to utilize variables declared in invite.php
        global $font_size;
        
        // check whether the file exists at the location given
        if(file_exists($file))
        {
            // read the file into a PHP string
            $body = file_get_contents($file);
            
            // write the string (likely a few paragraphs) to the pdf, leaving
            // enough space between lines so text isn't compressed vertically
            $pdf->MultiCell(0, ($font_size / 72.0), $body, 0, "L");
            $pdf->Ln();
          
            // for cleanliness, leave half-inch of space before next print
            skip($pdf, 0.5);
        }
        
        // if file does not exist, exist the program
        else
        {
            print("Cannot open " . $file . "\n");
            die();
        }
    }
    
    /* print_date()
       parameters (2): pdf object, PHP date object converted to string format
       output: none (writes directly to $pdf)
       
       Writes the date portion of the letter to the specified pdf object
    */
    function print_date($pdf, $date)
    {
        // writes the date line right-justified
        print_line($pdf, $date, "R");
        
        // for cleanliness, leave half-inch of space before next print
        skip($pdf, 0.5);
    }
    
    /* print_greeting()
       parameters (2): pdf object, name string
       
       Writes the greeting portion of the letter to the specified pdf object
    */
    function print_greeting($pdf, $name)
    {
        // writes the greeting line left-justified
        print_line($pdf, "Dear " . $name . ",", "L");
        
        // for cleanliness, leave quarter-inch of space before next print
        skip($pdf, 0.25);
    }
    
    /* print_line()
       parameters (3): pdf object, text to be written, alignment preference
       
       Writes a single line to the specified pdf object with intended format
    */
    function print_line($pdf, $message, $align)
    {
        // allow function to utilize variables declared in invite.php
        global $font_size;
        
        // write the string to the pdf, moving the position cursor down one
        // "letter height" so text isn't compressed vertically
        $pdf->Cell(0, ($font_size / 72.0), $message, 0, 0, $align);
        $pdf->Ln();
    }
    
    /* print_greeting()
       parameters (3): pdf object, signoff string, name string
       
       Writes the greeting portion of the letter to the specified pdf object,
       allowing for custom signoffs as well as name
    */
    function print_signature($pdf, $signoff, $name)
    {
        // writes the signoff line right-justified
        print_line($pdf, $signoff, "R");
        
        // for cleanliness, leave half-inch of space before next print
        skip($pdf, 0.5);
        
        // writes the name right-justified
        print_line($pdf, $name, "R");
    }

    /* save_as()
       parameters (2): pdf object, destination filename
       
       Converts the pdf object we've been constructing into a filesystem-
       accessible PDF file
    */
    function save_as($pdf, $filename)
    {
        $pdf->Output('F', $filename);
    }
    
    /* skip()
       parameters (2): pdf object, distance to skip downward
       
       Advances the position cursor in the file down a number of inches
    */
    function skip($pdf, $inches)
    {
        $pdf->Ln($inches);
    }
?>