<?php

    /**
     * helpers.php
     *
     * CSCI-P 14300
     * checkout
     * Adapted from CS50
     *
     * TODO
     */
     
    require_once("../includes/config.php");
    
    // PROBLEM 0 - HOMEPAGE
    
    // 0.0 - BOOKS
    function books() {
        // TODO
        return NULL;
    }
    
    // 0.1 - AUTHOR
    function author_name($author_id) {
        // TODO
        return NULL;
    }
    
    // PROBLEM 1 - INVENTORY
    
    // 1.0 - TOTAL
    function book_count() {
        // TODO
        return NULL;
    }
    
    // 1.1 - DISTINCT
    function distinct_book_count() {
        // TODO
        return NULL;
    }
    
    // 1.2 - OUT
    function currently_out() {
        // TODO
        return NULL;
    }
    
    // PROBLEM 2 - CATALOG
    
    // 2.0 - ANTHOLOGY
    function books_by_author($author_last) {
        // TODO
        return NULL;
    }
    
    // 2.1 - SUGGESTION
    function suggest($books) {
        // TODO
        return NULL;
    }
    
    // PROBLEM 3 - OVERDUE
    
    // 3.0 - BORROWED
    function checked_out($first_name, $last_name) {
        // TODO
        return NULL;
    }
    
    // 3.1 - LATE
    function late($first_name, $last_name, $today) {
        // TODO
        return NULL;
    }
    
    // 3.2 - ELIGIBLE
    function approve_checkout($checked_out, $overdue, $num) {
        // TODO
        return NULL;
    }
    
?>