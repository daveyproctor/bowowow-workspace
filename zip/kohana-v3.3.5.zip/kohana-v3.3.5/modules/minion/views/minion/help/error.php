<?php echo $error; ?>

Run 

    index.php --uri=minion

for more help
