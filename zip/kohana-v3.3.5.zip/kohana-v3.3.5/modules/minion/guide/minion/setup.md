# Minion Setup

[!!] Since Kohana `3.3.x`, minion requires no additional setup to use.