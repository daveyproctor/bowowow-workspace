<?php defined('SYSPATH') or die('No direct script access.');

class Cache_Apcu extends Kohana_Cache_Apcu {}
