<?php defined('SYSPATH') OR die('No direct script access.');

class Log_StdErr extends Kohana_Log_StdErr {}
