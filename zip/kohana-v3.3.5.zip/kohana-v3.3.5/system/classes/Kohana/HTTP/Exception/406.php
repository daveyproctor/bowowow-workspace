<?php defined('SYSPATH') OR die('No direct script access.');

class Kohana_HTTP_Exception_406 extends HTTP_Exception {

	/**
	 * @var   integer    HTTP 406 Not Acceptable
	 */
	protected $_code = 406;

}
