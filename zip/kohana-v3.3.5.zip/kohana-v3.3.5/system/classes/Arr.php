<?php defined('SYSPATH') OR die('No direct script access.');

class Arr extends Kohana_Arr {}
